from .Chiloc import Chiloc
from .Locator import CityLocator
from .helper import city_code_init

city_code_init()