from setuptools import setup 

setup(name='chiloc',
version='1.0.2',
description='Chinese Location Finder',
packages=['chiloc'],
zip_safe=False)