from .Locator import CityLocator
import helper 

helper.city_code_init()